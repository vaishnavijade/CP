class finalvariable 
{
	final static float PI = (float)3.1415;

	public static void main(String []args) 
	{
		PI = (float)3.14;
	}	
}	
