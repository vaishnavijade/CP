class test {
  test() { }
  private test(byte b) { }
  test(int x) { }
  test(int x, int[] y) { }
  void test() { } 
  void test2() { } 
  test(short s){}
  //static test(float f) { } 
  //final test(long x) { } 
  //abstract test(char c) { } 
  test(int t, int... x) { } 
}