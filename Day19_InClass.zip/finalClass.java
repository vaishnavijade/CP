final class demo
{
}	

class demo2 extends demo {
  public static void main(String []args) 
	{

	}	
}
