class demo 
{
  final void m1(){
    System.out.println("method m1 called");
  }
}	

class demo2 extends demo {
  void m1(){
    System.out.println("derived class method m1 called");
  }
  public static void main(String []args) 
  {

  }	
}


